NOV AWEAR — SYNTHETIC E-COMMERCE TABLEAU PROJECT DATA

Purpose
-------
NovaWear is a fictional direct-to-consumer fashion retailer.
The dataset is designed for a Tableau Public portfolio/project dashboard on:
E-commerce Performance & Customer Intelligence.

All records are synthetic.

Files
-----
customers.csv      4,628 rows
products.csv       220 rows
sellers.csv        83 rows
orders.csv         7,824 rows
order_items.csv    13,166 rows
payments.csv       7,840 rows
reviews.csv        4,803 rows
returns.csv        822 rows
data_dictionary.csv
cleaning_checklist.csv

Recommended Tableau relationship model
--------------------------------------
Customers.customer_id  -> Orders.customer_id
Orders.order_id         -> Order_Items.order_id
Products.product_id     -> Order_Items.product_id
Sellers.seller_id       -> Order_Items.seller_id
Orders.order_id         -> Payments.order_id
Orders.order_id         -> Reviews.order_id
Orders.order_id         -> Returns.order_id
Products.product_id     -> Returns.product_id

Time period
-----------
Orders span 1 January 2024 to 31 December 2025.

Intentional data-quality problems
---------------------------------
This dataset is deliberately dirty so data cleaning can form part of your project.

It includes:
- Null / missing values
- Duplicate records and duplicate keys
- Inconsistent spelling, case and whitespace in categories
- Mixed and malformed date formats
- Impossible date sequences
- Invalid numeric values and outliers
- Orphan foreign keys
- Product and seller IDs swapped in some order-item rows
- A small number of shifted/misaligned fields

Important:
Not every null is an error. For example:
- Cancelled/processing orders may not have shipped or delivered dates.
- Reviews may legitimately have no title/message/response.
- In-transit/requested returns may not yet have a refund or received date.

Suggested business questions
----------------------------
1. How are revenue, orders, customers and AOV trending?
2. Which products, regions and channels drive revenue and gross profit?
3. Which customer segments are most valuable?
4. Where are cancellations and returns concentrated?
5. Are late deliveries associated with lower review scores?
6. Which products or sellers contribute to poor customer experience?

Suggested calculated fields after cleaning
------------------------------------------
Line Revenue = Quantity * Unit Price * (1 - Discount % / 100)
Gross Profit = Line Revenue - (Quantity * Product Unit Cost)
Late Delivery Flag = Delivered Date > Estimated Delivery Date
Delivery Days = Delivered Date - Purchase Date
Return Rate = Returned Orders / Delivered Orders
Cancellation Rate = Cancelled Orders / Total Orders
Average Order Value = Revenue / Distinct Orders
Repeat Customer Flag = Customer with more than 1 valid order

No exact dirty-row locations are provided so that you can discover,
document and justify the cleaning yourself.
